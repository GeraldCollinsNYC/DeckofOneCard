//
//  CardError.swift
//  DeckOfOneCard
//
//  Created by Collins on 11/17/20.
//

import Foundation

enum CardError: LocalizedError {
    
    case invalidURL
    case thrownError(Error)
    case noData
    case unableToDecode
    
    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return self.errorDescription
            
        case .thrownError(let error):
            return error.localizedDescription
            
        case .noData:
            return "Please!!!! Data!! Please!!! Get in here!!!!!"
            
        case .unableToDecode:
                  return "The server responded with bad data."
        }
    }
    
}
