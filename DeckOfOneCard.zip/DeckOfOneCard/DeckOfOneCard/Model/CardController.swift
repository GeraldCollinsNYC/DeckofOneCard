//
//  CardController.swift
//  DeckOfOneCard
//
//  Created by Collins on 11/17/20.
//

import UIKit


class CardController {
    
    static private let baseURL = URL(string: "https://deckofcardsapi.com/api/deck/new")
    static let cardComponent = "draw/"
    //static let countComponent = "deck_count"
    
    
    static func fetchCard(completion: @escaping (Result <Card, CardError>) -> Void) {
        
        guard let baseURL = baseURL else { return completion (.failure(.invalidURL))}
        let componentURL = baseURL.appendingPathComponent(cardComponent)
        var components = URLComponents(url: componentURL, resolvingAgainstBaseURL: true)
    
        components?.queryItems = [URLQueryItem(name: "count", value: "1")]
        
        guard let finalURL = components?.url else { return
            completion(.failure(.invalidURL))}
        print(finalURL)
        
        URLSession.shared.dataTask(with: finalURL) { (data, _, error) in
            if let error = error {
                print(error.localizedDescription)
                return completion(.failure(.thrownError(error)))
            }
            
            guard let data = data else { return completion(.failure(.noData))}
            
            do {
                let topLevelObject = try JSONDecoder().decode(TopLevelObject.self, from: data)
                guard let card = topLevelObject.cards.first else { return completion(.failure(.noData))}
                return completion(.success(card))
            } catch {
                return completion(.failure(.noData))
            }
        } .resume()
        
        
    } // End of Fetch Card function
    
    static func fetchImage(for card: Card, completion: @escaping (Result <UIImage, CardError>) -> Void) {
        let url = card.image
        URLSession.shared.dataTask(with: url) { (data, _, error) in
            if let error = error {
                print(error.localizedDescription)
                return completion(.failure(.thrownError(error)))
            }
            
            guard let data = data else { return completion(.failure(.noData))}
            
            guard let image = UIImage(data: data) else { return completion(.failure(.unableToDecode)) }
            completion(.success(image))
           
            
        } .resume()
        
        
    }  // End of Class
    
}
